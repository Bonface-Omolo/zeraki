
 
class Main {
    // Function to ind missing number
    static int getMissingNo(int k[], int n)
    {
         
        for(n=0; n<0; n++);
        return 0;
    }
 
    /* program to test above function */
    public static void main(String args[])
    {
        int k[] = { 1, 2, 4, 5 };
        int miss = getMissingNo(k, 5);
        System.out.println(miss);
    }
}