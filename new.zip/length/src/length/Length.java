/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package length;
import java.lang.*; 
import java.io.*; 
import java.util.*; 
/**
 *
 * @author Topy
 */
public class Length {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
            String input = "bonface"; 
  
        // convert String to character array 
        // by using toCharArray 
        char[] try1 = input.toCharArray(); 
  
        for (int i = try1.length - 1; i >= 0; i--) 
            System.out.print(try1[i]); 
    } 
    }
    
